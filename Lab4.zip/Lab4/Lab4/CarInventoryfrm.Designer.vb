﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CarInventoryfrm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblMake = New System.Windows.Forms.Label()
        Me.lblModel = New System.Windows.Forms.Label()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.lblPrice = New System.Windows.Forms.Label()
        Me.lblIsNew = New System.Windows.Forms.Label()
        Me.chkIsNew = New System.Windows.Forms.CheckBox()
        Me.cbMake = New System.Windows.Forms.ComboBox()
        Me.lvwCars = New System.Windows.Forms.ListView()
        Me.chIsNew = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chIdentificationNumber = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chMake = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chModel = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chYear = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.chPrice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.tbModel = New System.Windows.Forms.TextBox()
        Me.tbPrice = New System.Windows.Forms.TextBox()
        Me.lbResult = New System.Windows.Forms.Label()
        Me.btnEnter = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.ttCarInventory = New System.Windows.Forms.ToolTip(Me.components)
        Me.nudYear = New System.Windows.Forms.NumericUpDown()
        CType(Me.nudYear, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblMake
        '
        Me.lblMake.AutoSize = True
        Me.lblMake.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblMake.Location = New System.Drawing.Point(56, 10)
        Me.lblMake.Name = "lblMake"
        Me.lblMake.Size = New System.Drawing.Size(37, 13)
        Me.lblMake.TabIndex = 0
        Me.lblMake.Text = "&Make:"
        Me.lblMake.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblModel
        '
        Me.lblModel.AutoSize = True
        Me.lblModel.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblModel.Location = New System.Drawing.Point(54, 37)
        Me.lblModel.Name = "lblModel"
        Me.lblModel.Size = New System.Drawing.Size(39, 13)
        Me.lblModel.TabIndex = 2
        Me.lblModel.Text = "M&odel:"
        Me.lblModel.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblYear
        '
        Me.lblYear.AutoSize = True
        Me.lblYear.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblYear.Location = New System.Drawing.Point(61, 63)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(32, 13)
        Me.lblYear.TabIndex = 4
        Me.lblYear.Text = "&Year:"
        Me.lblYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblPrice
        '
        Me.lblPrice.AutoSize = True
        Me.lblPrice.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblPrice.Location = New System.Drawing.Point(59, 89)
        Me.lblPrice.Name = "lblPrice"
        Me.lblPrice.Size = New System.Drawing.Size(34, 13)
        Me.lblPrice.TabIndex = 6
        Me.lblPrice.Text = "&Price:"
        Me.lblPrice.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblIsNew
        '
        Me.lblIsNew.AutoSize = True
        Me.lblIsNew.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblIsNew.Location = New System.Drawing.Point(61, 114)
        Me.lblIsNew.Name = "lblIsNew"
        Me.lblIsNew.Size = New System.Drawing.Size(32, 13)
        Me.lblIsNew.TabIndex = 8
        Me.lblIsNew.Text = "&New:"
        Me.lblIsNew.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'chkIsNew
        '
        Me.chkIsNew.AutoSize = True
        Me.chkIsNew.Location = New System.Drawing.Point(99, 114)
        Me.chkIsNew.Name = "chkIsNew"
        Me.chkIsNew.Size = New System.Drawing.Size(15, 14)
        Me.chkIsNew.TabIndex = 9
        Me.ttCarInventory.SetToolTip(Me.chkIsNew, "This is a checkbox to check if the car is either new (checked) or used (un-checke" &
        "d)")
        Me.chkIsNew.UseVisualStyleBackColor = True
        '
        'cbMake
        '
        Me.cbMake.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbMake.FormattingEnabled = True
        Me.cbMake.Items.AddRange(New Object() {"Hyundai", "Ford", "Chevrolet", "Nissan", "GMC", "Audi", "BMW", "Volkswagen", "Toyota", "Tesla", "Honda", "Buick", "Acura", "Mercedes", "Subaru", "Dodge Ram"})
        Me.cbMake.Location = New System.Drawing.Point(100, 6)
        Me.cbMake.Name = "cbMake"
        Me.cbMake.Size = New System.Drawing.Size(120, 21)
        Me.cbMake.TabIndex = 1
        Me.ttCarInventory.SetToolTip(Me.cbMake, "This is for choosing the make of a car")
        '
        'lvwCars
        '
        Me.lvwCars.CheckBoxes = True
        Me.lvwCars.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.chIsNew, Me.chIdentificationNumber, Me.chMake, Me.chModel, Me.chYear, Me.chPrice})
        Me.lvwCars.FullRowSelect = True
        Me.lvwCars.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable
        Me.lvwCars.HideSelection = False
        Me.lvwCars.Location = New System.Drawing.Point(12, 134)
        Me.lvwCars.MultiSelect = False
        Me.lvwCars.Name = "lvwCars"
        Me.lvwCars.Size = New System.Drawing.Size(407, 158)
        Me.lvwCars.TabIndex = 10
        Me.ttCarInventory.SetToolTip(Me.lvwCars, "Displays entered in car information")
        Me.lvwCars.UseCompatibleStateImageBehavior = False
        Me.lvwCars.View = System.Windows.Forms.View.Details
        '
        'chIsNew
        '
        Me.chIsNew.Text = "New"
        '
        'chIdentificationNumber
        '
        Me.chIdentificationNumber.Text = "ID"
        '
        'chMake
        '
        Me.chMake.Text = "Make"
        '
        'chModel
        '
        Me.chModel.Text = "Model"
        '
        'chYear
        '
        Me.chYear.Text = "Year"
        '
        'chPrice
        '
        Me.chPrice.Text = "Price"
        '
        'tbModel
        '
        Me.tbModel.Location = New System.Drawing.Point(100, 33)
        Me.tbModel.Name = "tbModel"
        Me.tbModel.Size = New System.Drawing.Size(120, 20)
        Me.tbModel.TabIndex = 3
        Me.ttCarInventory.SetToolTip(Me.tbModel, "This is for entering the model of the car")
        '
        'tbPrice
        '
        Me.tbPrice.Location = New System.Drawing.Point(100, 86)
        Me.tbPrice.Name = "tbPrice"
        Me.tbPrice.Size = New System.Drawing.Size(120, 20)
        Me.tbPrice.TabIndex = 7
        Me.ttCarInventory.SetToolTip(Me.tbPrice, "This is for entering the price of the car")
        '
        'lbResult
        '
        Me.lbResult.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lbResult.Location = New System.Drawing.Point(12, 295)
        Me.lbResult.Name = "lbResult"
        Me.lbResult.Size = New System.Drawing.Size(407, 94)
        Me.lbResult.TabIndex = 11
        Me.ttCarInventory.SetToolTip(Me.lbResult, "Displays information describing the entered in car.")
        '
        'btnEnter
        '
        Me.btnEnter.Location = New System.Drawing.Point(182, 400)
        Me.btnEnter.Name = "btnEnter"
        Me.btnEnter.Size = New System.Drawing.Size(75, 23)
        Me.btnEnter.TabIndex = 12
        Me.btnEnter.Text = "&Enter"
        Me.ttCarInventory.SetToolTip(Me.btnEnter, "Press to enter in information")
        Me.btnEnter.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnReset.Location = New System.Drawing.Point(263, 400)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 13
        Me.btnReset.Text = "&Reset"
        Me.ttCarInventory.SetToolTip(Me.btnReset, "Press to reset the form")
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(344, 400)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 14
        Me.btnExit.Text = "E&xit"
        Me.ttCarInventory.SetToolTip(Me.btnExit, "Press to exit the program")
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'nudYear
        '
        Me.nudYear.Location = New System.Drawing.Point(99, 60)
        Me.nudYear.Maximum = New Decimal(New Integer() {2020, 0, 0, 0})
        Me.nudYear.Minimum = New Decimal(New Integer() {1920, 0, 0, 0})
        Me.nudYear.Name = "nudYear"
        Me.nudYear.Size = New System.Drawing.Size(121, 20)
        Me.nudYear.TabIndex = 5
        Me.ttCarInventory.SetToolTip(Me.nudYear, "Select the Year the car was made.")
        Me.nudYear.Value = New Decimal(New Integer() {2020, 0, 0, 0})
        '
        'CarInventoryfrm
        '
        Me.AcceptButton = Me.btnEnter
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnReset
        Me.ClientSize = New System.Drawing.Size(431, 435)
        Me.Controls.Add(Me.nudYear)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnter)
        Me.Controls.Add(Me.lbResult)
        Me.Controls.Add(Me.tbPrice)
        Me.Controls.Add(Me.tbModel)
        Me.Controls.Add(Me.lvwCars)
        Me.Controls.Add(Me.cbMake)
        Me.Controls.Add(Me.chkIsNew)
        Me.Controls.Add(Me.lblIsNew)
        Me.Controls.Add(Me.lblPrice)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.lblModel)
        Me.Controls.Add(Me.lblMake)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "CarInventoryfrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Car Inventory"
        CType(Me.nudYear, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblMake As Label
    Friend WithEvents lblModel As Label
    Friend WithEvents lblYear As Label
    Friend WithEvents lblPrice As Label
    Friend WithEvents lblIsNew As Label
    Friend WithEvents chkIsNew As CheckBox
    Friend WithEvents cbMake As ComboBox
    Friend WithEvents lvwCars As ListView
    Friend WithEvents chIsNew As ColumnHeader
    Friend WithEvents chIdentificationNumber As ColumnHeader
    Friend WithEvents chMake As ColumnHeader
    Friend WithEvents chModel As ColumnHeader
    Friend WithEvents chYear As ColumnHeader
    Friend WithEvents chPrice As ColumnHeader
    Friend WithEvents tbModel As TextBox
    Friend WithEvents tbPrice As TextBox
    Friend WithEvents lbResult As Label
    Friend WithEvents btnEnter As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents ttCarInventory As ToolTip
    Friend WithEvents nudYear As NumericUpDown
End Class
