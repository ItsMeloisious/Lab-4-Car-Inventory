﻿'Author: Kyle Roddick
'Date: March 11, 2020
'Description: 
'   This class represesnts car objects with propertites for the make, model, year, price, and some other stuff.

Option Strict On
Public Class CarClass


    Private Shared carCount As Integer = 0      'private shared variable to hold the car count as integer.
    Private carIdentificationNumber As String = String.Empty   'private variable to hold the identification number.
    Private carMake As String = String.Empty   'private variable to hold the car make as string.
    Private carModel As String = String.Empty     'private variable to hold the car modelas string.
    Private carYear As Integer = 0          'private variable to hold the car year as integer.
    Private carPrice As Decimal = 0.0D     'private variable to hold car price as a decimal.
    Private carIsNew As Boolean = False    'private variable to hold whether the car is new or not.



#Region "Constructors"
    ''' <summary>
    ''' Default Constructor
    ''' Increments Car Count
    ''' </summary>
    Friend Sub New()

        carCount += 1
        carIdentificationNumber = carCount.ToString
    End Sub

    ''' <summary>
    ''' Parameterized constructor that sets all class values based on arguments passed in
    ''' </summary>
    ''' <param name="makeValue">Cars Manufacterer</param>
    ''' <param name="modelValue">Cars Model Name</param>
    ''' <param name="yearValue">Year Car Was Made</param>
    ''' <param name="priceValue">Cars Price</param>
    ''' <param name="newValue">True if Car is new, False if the car is used</param>
    Public Sub New(makeValue As String, modelValue As String, yearValue As Integer, priceValue As Decimal, newValue As Boolean)

        Me.New()

        carMake = makeValue
        carModel = modelValue
        carYear = yearValue
        carPrice = priceValue
        carIsNew = newValue

    End Sub
#End Region

#Region "Property Procedures"

    ''' <summary>
    ''' Returns the number of car objects
    ''' </summary>
    ''' <returns></returns>
    Friend Shared ReadOnly Property Count As Integer
        Get
            Return carCount
        End Get
    End Property

    ''' <summary>
    ''' Returns the car identification number as a string value
    ''' </summary>
    ''' <returns></returns>
    Public ReadOnly Property IdentificationNumber() As String
        Get
            Return carIdentificationNumber
        End Get
    End Property

    ''' <summary>
    ''' Returns the cars manufacterer as a string value
    ''' </summary>
    ''' <returns></returns>
    Friend Property Make() As String
        Get
            Return carMake
        End Get
        Set(value As String)
            carMake = value
        End Set
    End Property

    ''' <summary>
    ''' Returns the cars's model as a string value
    ''' </summary>
    ''' <returns></returns>
    Friend Property Model() As String
        Get
            Return carModel
        End Get
        Set(value As String)
            carModel = value
        End Set
    End Property

    ''' <summary>
    ''' Returns the cars's year as a integer value
    ''' </summary>
    ''' <returns></returns>
    Friend Property Year() As Integer
        Get
            Return carYear
        End Get
        Set(value As Integer)
            carYear = value
        End Set
    End Property

    ''' <summary>
    ''' Returns the cars's price as a decimal value
    ''' </summary>
    ''' <returns></returns>
    Friend Property Price() As Decimal
        Get
            Return carPrice
        End Get
        Set(value As Decimal)
            carPrice = value
        End Set
    End Property


    ''' <summary>
    ''' Returns a boolean value indicating whether the car is new
    ''' </summary>
    ''' <returns>True if the car is new; False if the car is used</returns>
    Friend Property IsNew() As Boolean
        Get
            Return carIsNew
        End Get
        Set(value As Boolean)
            carIsNew = value
        End Set
    End Property
#End Region

#Region "Methods"

    ''' <summary>
    ''' Returns a string describing the car
    ''' </summary>
    ''' <returns>a string describing the car</returns>
    Public Function GetCarData() As String
        Return IIf(carIsNew, "New", "Used").ToString & carYear.ToString & " " & carMake & " " & carModel & " for " & carPrice.ToString("c")
    End Function

#End Region

End Class
