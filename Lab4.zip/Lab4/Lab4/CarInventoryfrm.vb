﻿' Project: Lab 5
' Author: Kyle Roddick
' Date: 03/23/20
' Description: A form that uses classes and object to validate and return information given by a user. With this form, it allows a user to enter in information about different cars they have in their car inventory. They enter in a make, model, year, price, and check 
'              off a checkbox if their car is new, or uncheck it if its used. The user then enters the data in and it is saved in a list, and displays information in a result
'              label of the entered data. The user can enter more data on cars and can be input/save as much information as they want. The user can even change data by just 
'              clicking on a car in the list view and changing it in the input boxes and then re-entering it in to save. The user can reset any information that has been entered
'              in the texboxes, drop down, or numeric up-down lists by clicking the reset button and will reset to its original state. And lastly the user can exit the form.


Option Strict On
Public Class CarInventoryfrm

#Region "Variable Declarations"
    Dim selectedCar As CarClass ' declare a car class object
    Dim isCarSelected As Boolean = False
    Dim isAddingToListView As Boolean = False
    Dim carList As New List(Of CarClass)

    Const DefaultYear As Integer = 2020 ' a constant to set the default value of the year to 2020
#End Region

    ''' <summary>
    ''' Attempt to enter a new car and add it to the list.
    ''' </summary>
#Region "Event Handlers"

    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click

        ' Validate the data in the form
        If IsValidInput() = True Then

            ' If a car is selected
            If Not isCarSelected Then

                ' Create a new car and add it to the list
                selectedCar = New CarClass(cbMake.Text, tbModel.Text, CInt(nudYear.Value), CDec(tbPrice.Text), chkIsNew.Checked)
                carList.Add(selectedCar)
                lbResult.Text = selectedCar.GetCarData

                ' Else if currentCar exists, we will be editing it
            ElseIf selectedCar.IdentificationNumber.Trim.Length > 0 Then

                ' Update the existing car based on the entered values
                selectedCar.Year = CInt(nudYear.Value)
                selectedCar.Model = tbModel.Text
                selectedCar.Price = CDec(tbPrice.Text)
                selectedCar.IsNew = chkIsNew.Checked
                selectedCar.Make = cbMake.Text
                lbResult.Text = selectedCar.GetCarData
            End If

        End If

        SetDefaults()

    End Sub

    ''' <summary>
    ''' Resets the form to its default states Procedure SetDefaults.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        SetDefaults()
    End Sub

    ''' <summary>
    ''' Close the form
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    ''' <summary>
    ''' Event handler for the event that a car is selected in the ListView
    ''' </summary>
    Private Sub lvwCar_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lvwCars.SelectedIndexChanged

        If lvwCars.SelectedIndices.Count = 1 Then
            selectedCar = carList(lvwCars.SelectedIndices(0))
            isCarSelected = True

            cbMake.Text = selectedCar.Make
            tbModel.Text = selectedCar.Model
            nudYear.Value = selectedCar.Year
            tbPrice.Text = CType(selectedCar.Price, String)
            chkIsNew.Checked = selectedCar.IsNew

        Else
            isCarSelected = False
        End If

    End Sub

    ''' <summary>
    ''' This event handler is supposed to stop you from checking a checkbox in the list view.
    ''' </summary>
    Private Sub lvwCars_ItemCheck(sender As Object, e As ItemCheckEventArgs) Handles lvwCars.ItemCheck

        ' If we're not currently adding cars to the list
        If Not isAddingToListView Then

            ' Maintain the old checkbox value
            e.NewValue = e.CurrentValue

        End If

    End Sub
#End Region


#Region "Procedures"
    ''' <summary>
    ''' IsValidInput - validates the data in each control to ensure that the user has entered apprpriate values
    ''' </summary>
    ''' <returns>Boolean</returns>
    Private Function IsValidInput() As Boolean

        Dim returnValue As Boolean = True
        Dim outputMessage As String = String.Empty


        ' check if the model name has been entered
        If tbModel.Text.Trim.Length = 0 Then

            ' If not set the error message
            outputMessage = "Please enter the cars model name." & vbCrLf

            ' And, set the return value to false
            returnValue = False

        End If

        ' check if the price has been entered
        If tbPrice.Text.Trim.Length = 0 Then

            ' If not set the error message
            outputMessage = "Please enter the price of the car." & vbCrLf

            ' And, set the return value to false
            returnValue = False

        End If

        ' check to see if any value
        ' did not validate
        If returnValue = False Then

            ' show the message(s) to the user
            lbResult.Text = "ERRORS:" & vbCrLf & outputMessage

        End If

        lbResult.Text = outputMessage

        ' return the boolean value
        ' true if it passed validation
        ' false if it did not pass validation
        Return returnValue

    End Function

    ''' <summary>
    ''' Resets the forms as well as any required class-level variables to their default state
    ''' </summary>
    Private Sub SetDefaults()
        cbMake.Items.Clear()    'Clears the List of Car Makes (resets the combo box to blank, so you have to give recode each individual collection/item
        cbMake.Items.Insert(0, "Hyundai")
        cbMake.Items.Insert(1, "Ford")
        cbMake.Items.Insert(2, "Chevrolet")
        cbMake.Items.Insert(3, "Nissan ")
        cbMake.Items.Insert(4, "GMC")
        cbMake.Items.Insert(5, "Audi")
        cbMake.Items.Insert(6, "BMW")
        cbMake.Items.Insert(7, "Volkswagen")
        cbMake.Items.Insert(8, "Toyota")
        cbMake.Items.Insert(9, "Tesla")
        cbMake.Items.Insert(10, "Honda")
        cbMake.Items.Insert(11, "Buick")
        cbMake.Items.Insert(12, "Acura")
        cbMake.Items.Insert(13, "Mercedes")
        cbMake.Items.Insert(14, "Subaru")
        cbMake.Items.Insert(15, "Dodge Ram")
        tbModel.Clear()     'Clears the car model textbox if anything is entered in it.
        nudYear.Value = DefaultYear     'Sets the year of the car to its default year (2020).
        tbPrice.Clear()     'Clears the car price if anything is entered in it.
        chkIsNew.Checked = False    'Clears the checkbox if the user has it checked but hasnt submitted their work.
        lbResult.Text = String.Empty ' Clears the result/output textbox.

        PopulateList() 'Sub procedure to populate the list of cars entered

        isCarSelected = False 'Sets selection of car to false

        cbMake.Focus() ' Puts focus on the Make of car combo box after form is reset

    End Sub

    Sub PopulateList()

        ' Clear the items from the listview control
        lvwCars.Items.Clear()

        ' This For loop re-populates the list
        For index As Integer = 0 To carList.Count - 1

            ' instantiate a new ListViewItem named carItem
            Dim carItem As New ListViewItem()

            ' assign the values to the checked control
            ' and the subitems
            carItem.Checked = carList(index).IsNew
            carItem.SubItems.Add(carList(index).IdentificationNumber.ToString())
            carItem.SubItems.Add(carList(index).Make)
            carItem.SubItems.Add(carList(index).Model)
            carItem.SubItems.Add(carList(index).Year.ToString)
            carItem.SubItems.Add(carList(index).Price.ToString)


            ' Indicate that we are adding cars to the ListView
            isAddingToListView = True

            ' add the new instantiated and populated ListViewItem
            ' to the listview control
            lvwCars.Items.Add(carItem)

            ' Indicate that we are done adding characters to the ListView
            isAddingToListView = False

        Next

    End Sub

#End Region

End Class
